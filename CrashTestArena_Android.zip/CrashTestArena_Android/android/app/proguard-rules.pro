# Oyun tamamen assets/index.html içinde; Kotlin tarafında yansıma (reflection) yok.
-keep class com.emir.crashtestarena.MainActivity { *; }
