plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.emir.crashtestarena"
    compileSdk = 36

    defaultConfig {
        // Play Store'da benzersiz olmalı: istersen kendi paket adınla değiştir (örn. com.seninadin.crashtest)
        applicationId = "com.emir.crashtestarena"
        minSdk = 24
        targetSdk = 36          // Google Play: 31 Ağustos 2026'dan beri yeni uygulamalar için zorunlu
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
}
