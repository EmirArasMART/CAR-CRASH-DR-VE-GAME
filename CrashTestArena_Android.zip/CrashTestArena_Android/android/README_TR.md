# Crash Test Arena – Android (Play Store) projesi

Oyunun fiziği ve haritası bilgisayardaki sürümle aynı. `app/src/main/assets/index.html` **mağaza sürümü**:
araç adları uydurma (Arven Sedan, Selvane Ala, Tarsis Terra, Orvane Grand Tourer), modellerdeki marka
logoları / yazıları / plaka yazıları silindi, Civetta yerine Orvane Grand Tourer var ve sağ üstteki **i** düğmesi
lisans / yazar ekranını açıyor (CC lisanslarının zorunlu kıldığı atıf burada).
Telefonda klavye olmadığı için sadece dokunmatik cihazlarda ekran tuşları açılıyor
(direksiyon ◀ ▶, GAZ, FREN/geri, EL FRENİ, üstte Araç değiştir / Onar / Kamera / Harita / Bölgeler,
tek parmakla sürükle = kamerayı döndür, iki parmak = yakınlaştır).

## 1) Android Studio'da aç ve dene
1. Android Studio (2025.1 veya yenisi) → **Open** → bu `android` klasörünü seç.
2. Gradle senkronizasyonunu bekle (ilk seferde internetten AGP 8.11.1 / Gradle 8.14.3 iner).
   Android Studio sürüm yükseltmesi önerirse kabul edebilirsin.
3. Telefonu USB hata ayıklama ile bağla → **Run ▶**. (Ya da Build → Build APK(s) ile debug APK.)

## 2) Play Store için imzalı paket (AAB)
1. Build → **Generate Signed App Bundle or APK** → **Android App Bundle**.
2. Yeni bir anahtar deposu (keystore) oluştur. **Dosyayı ve şifreleri kaybetme**: güncellemeler için hep aynısı gerekir.
3. `release` seç → `app/release/app-release.aab` oluşur. Play Console'a bunu yükleyeceksin.

## 3) Play Console'da doldurulacaklar
- **Paket adı**: `com.emir.crashtestarena` (benzersiz olmalı; değiştirmek istersen `app/build.gradle.kts` içindeki
  `applicationId` ve `namespace` + klasör yolunu değiştir).
- **Hedef API**: 36 (Android 16) – 31 Ağustos 2026'dan beri yeni uygulamalar için zorunlu, projede ayarlı.
- **Uygulama simgesi** 512×512: `store/play_icon_512.png`
- **Öne çıkan görsel** 1024×500: `store/feature_graphic_1024x500.png`
- **Telefon ekran görüntüleri** (1920×1080): `store/screen*.png`
- **Gizlilik politikası**: `store/privacy_policy.html` dosyasını bir yere koy (ör. GitHub Pages) ve linkini ver.
- **Veri güvenliği formu**: "Veri toplanmıyor / paylaşılmıyor" (uygulamada internet izni bile yok).
- **İçerik derecelendirmesi**: insan yok, kan yok; araç hasarı → genelde "Herkes / PEGI 3".
- **Kategori**: Oyun → Yarış veya Simülasyon.
- Yeni kişisel geliştirici hesaplarında üretime çıkmadan önce **kapalı test** (en az 12 test kullanıcısı, 14 gün) isteniyor.

## Lisans kuralları (önemli)
- Arven, Tarsis ve Orvane modelleri **CC BY-NC-SA 4.0**: ticari kullanım yasak. Uygulama **ücretsiz** kalmalı,
  **reklam ve uygulama içi satın alma koyma**. Para kazanmak istersen bu modelleri kendi modellerinle değiştirmen gerekir.
- Oyun içindeki **i** ekranını kaldırma: yazar adı, kaynak linki ve lisans gösterilmek zorunda.
- Değiştirilmiş modeller de CC BY-NC-SA 4.0 kapsamında kalır.

## Performans
Telefonda oyun düşük çözünürlük ve küçük gölge haritasıyla başlar; kare hızı düşerse önce çözünürlüğü,
sonra gölgeleri otomatik kapatır. Sol üstte FPS göstergesi var.
